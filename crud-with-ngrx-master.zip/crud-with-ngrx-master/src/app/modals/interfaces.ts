export interface UserDetails {
    id: number;
    first_name: string;
    last_name: string;
    avatar: '',
    gender: string;
    mobile: number;
    email: string;
    salary: number;
}
