export interface UserDetails {
    id?: number;
    first_name: string;
    last_name: string;
    gender: string;
    avatar: string;
    mobile: number;
    email: string;
    salary: number;
}
