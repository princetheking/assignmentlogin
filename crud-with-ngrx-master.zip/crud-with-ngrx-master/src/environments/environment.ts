// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  // apiUrl: 'https://reqres.in',
  apiKey: "AIzaSyCX50bbF52qxbEWu_vklAM4uMou73gpIhE",
  apiUrl: "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword",
  firebaseConfig : {
    apiKey: "AIzaSyCX50bbF52qxbEWu_vklAM4uMou73gpIhE",
    authDomain: "ngrx-crud-4a875.firebaseapp.com",
    projectId: "ngrx-crud-4a875",
    storageBucket: "ngrx-crud-4a875.appspot.com",
    messagingSenderId: "395358518261",
    appId: "1:395358518261:web:7dbc22644ca381c54e7ebc",
    measurementId: "G-GCPRTDG7WC"
  }
  // apiUrl: 'https://bmchelix-cloudopsapi.onbmc.com/',
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.



// Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// import { getAnalytics } from "firebase/analytics";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// // For Firebase JS SDK v7.20.0 and later, measurementId is optional
// const firebaseConfig = {
//   apiKey: "AIzaSyCX50bbF52qxbEWu_vklAM4uMou73gpIhE",
//   authDomain: "ngrx-crud-4a875.firebaseapp.com",
//   projectId: "ngrx-crud-4a875",
//   storageBucket: "ngrx-crud-4a875.appspot.com",
//   messagingSenderId: "395358518261",
//   appId: "1:395358518261:web:7dbc22644ca381c54e7ebc",
//   measurementId: "G-GCPRTDG7WC"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
// const analytics = getAnalytics(app);



// debugtokenname = "6FFDB35F-2B27-4790-889F-32749D7FAD2D"