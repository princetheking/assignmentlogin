export const environment = {
  production: true,
  // apiUrl: 'https://reqres.in',
  apiKey: "AIzaSyCX50bbF52qxbEWu_vklAM4uMou73gpIhE",
  apiUrl: "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword",
  firebaseConfig : {
    apiKey: "AIzaSyCX50bbF52qxbEWu_vklAM4uMou73gpIhE",
    authDomain: "ngrx-crud-4a875.firebaseapp.com",
    projectId: "ngrx-crud-4a875",
    storageBucket: "ngrx-crud-4a875.appspot.com",
    messagingSenderId: "395358518261",
    appId: "1:395358518261:web:7dbc22644ca381c54e7ebc",
    measurementId: "G-GCPRTDG7WC"
  }
  // apiUrl: 'https://bmchelix-cloudopsapi.onbmc.com/',
};
