export let UserList = [
    {
        id: 1,
        firstName: 'Devglan',
        lastName: 'Devglan',
        gender: 'Male',
        mobile: 9087983433,
        email: 'devglan@gmail.com',
        salary: 3456,
    },
    {
        id: 2,
        firstName: 'Tom',
        lastName: 'Asr',
        gender: 'Male',
        mobile: 9087983433,
        email: 'tomasr@gmail.com',
        salary: 7823
    },
    {
        id: 3,
        firstName: 'Adam',
        lastName: 'Psr',
        gender: 'Female',
        mobile: 9087983433,
        email: 'adam@gmail.com',
        salary: 4234
    },
    {
        id: 4,
        firstName: 'smith',
        lastName: 'Psr',
        gender: 'Female',
        mobile: 9087983433,
        email: 'smithpsr@gmail.com',
        salary: 423400
    },
    {
        id: 5,
        firstName: 'akshay',
        lastName: 'kumar',
        gender: 'Male',
        mobile: 9087983433,
        email: 'akshay@gmail.com',
        salary: 530000
    }
];
